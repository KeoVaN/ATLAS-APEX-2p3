# PID Risk Spec

PID risk yönetişimi için taslak. (Taslak)