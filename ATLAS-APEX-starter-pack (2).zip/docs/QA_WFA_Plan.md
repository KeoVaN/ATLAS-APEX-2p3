# QA / WFA Plan

Walk-forward ve test planı. (Taslak)