# Telemetry Schema

Temel telemetri alanları ve örnekler. (Taslak)