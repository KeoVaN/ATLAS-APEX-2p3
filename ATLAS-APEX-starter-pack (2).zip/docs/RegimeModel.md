# Regime Model

Hurst eşikleri 0.55/0.45, RV bileşenleri. (Taslak)