# Dynamic Params Map

*_eff parametre haritası. (Taslak)