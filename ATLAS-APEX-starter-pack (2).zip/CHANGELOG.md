# Changelog
Tüm anlamlı değişiklikler burada kayıt altına alınır.
- v0.0.1: Başlangıç yapı ve şablonlar
