---
name: Feature Request
about: Yeni özellik isteği
---
**Öneri**  
**Neden? (etki)**  
**Kapsam / Dış-kapsam**  
**DoD / Kabul ölçütleri**  
