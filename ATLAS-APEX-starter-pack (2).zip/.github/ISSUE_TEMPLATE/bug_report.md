---
name: Bug Report
about: Hata bildirin
---
**Ne oldu?**  
**Beklenen davranış?**  
**Tekrar üretim adımları**  
**Log/ekran görüntüsü**  
**Sürüm / Commit**  
