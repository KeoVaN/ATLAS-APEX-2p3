## Özet
- [ ] Sprint / Modül:
- [ ] Bütçe: request<=35, plot<=64 (✓/✗)
- [ ] HTF hijyen (noRepaintHTF): (✓/✗)

## Değişiklikler
- FSM / Gate / Anti-Chop / Telemetri (uygun olanları işaretleyin)

## Test
- Canary: sembol/TF
- Replay/SS (varsa kanıt ekleyin)
