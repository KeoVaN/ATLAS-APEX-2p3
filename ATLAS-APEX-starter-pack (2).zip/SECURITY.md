# Güvenlik Politikası

- Gizli anahtar, token, API anahtarı, cüzdan bilgisi **commit etmeyin**.
- Zafiyet bildirimleri için: security@example.com (güncelleyin)
- Public rapor yerine özel e-posta tercih edilir.
- Şüpheli bir durum görürseniz Issue yerine e-posta atın.
